#!/bin/sh

make
(cd kissat; ./configure && make)
(cd cnf2knf; make)
