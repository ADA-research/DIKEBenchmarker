#!/bin/sh

make clean
(cd kissat; make clean)
(cd cnf2knf; make clean)
