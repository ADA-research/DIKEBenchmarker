/***********************************************************************[state.hpp]
Copyright(c) 2022, Muhammad Osama - Anton Wijs,
Technische Universiteit Eindhoven (TU/e).

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
**********************************************************************************/

#ifndef __STATE_
#define __STATE_

#include "datatypes.hpp"

namespace SeqFROST {

	struct VarState {

		byte_t state	: 3;
		byte_t dlcount	: 2;
		byte_t mab		: 1;
		byte_t subsume	: 1;
		byte_t probe	: 1;

		VarState() :
			state(0)
			, dlcount(0)
			, mab(0)
			, subsume(0)
			, probe(0)
			{ }
	};
}

#endif