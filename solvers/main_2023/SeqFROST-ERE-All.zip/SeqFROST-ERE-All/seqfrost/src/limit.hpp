/***********************************************************************[limit.hpp]
Copyright(c) 2022, Muhammad Osama - Anton Wijs,
Technische Universiteit Eindhoven (TU/e).

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
**********************************************************************************/

#ifndef __LIMIT_
#define __LIMIT_

#include "datatypes.hpp"
#include "scale.hpp"
#include "rephase.hpp"

namespace SeqFROST {

	struct Last {
		struct {
			uint64 conflicts, count;
			uint32 best, target;
			rephase_t type;
		} rephase;
		struct {
			uint32 decisions, unassigned;
			int rounds;
		} mdm;
		struct { uint64 reduces; } simplify, probe;
		struct { uint64 resolvents; } ternary;
		struct { int64 removed; } shrink;
		struct { uint32 literals; } transitive;

		Last() { RESETSTRUCT(this); }
	};

	struct Limit {
		struct { uint64 ticks, conflicts; } mode;
		struct { uint64 conflicts; } restart;
		uint64 mdm;
		uint64 probe;
		uint64 reduce;
		uint64 rephase;
		uint64 forward;
		uint64 simplify;
		int keptsize, keptlbd;

		Limit() { RESETSTRUCT(this); }
	};

	struct Monitor { uint32 now, all; };

	struct Sleep {
		Monitor simplify, probe, ternary, autarky, debinary;
		Sleep() { RESETSTRUCT(this); }
	};

	#define DECAY_REPHASE(ELEM, DECAY) (ELEM.rephase.target *= (1.0 - (DECAY)))

	#define INIT_LIMIT(RESULT, OPTION_INC, SCALE_INCREASE) \
	  RESULT = (SCALE_INCREASE) ? relscale(ORIGINALS, OPTION_INC) : (OPTION_INC); \

	#define INCREASE_LIMIT(Option, N, SCALING_FUNC, SCALE_INCREASE) \
	{ \
	  uint64 INC = opts.Option ## _inc; \
	  INC *= SCALING_FUNC( N ) + 1; \
	  const uint64 SCALED = (SCALE_INCREASE) ? relscale(ORIGINALS, INC) : INC; \
	  limit.Option = stats.conflicts + SCALED; \
	  LOG2(2, "  %s limit increased to %lld conflicts by a weight %lld", __func__, limit.Option, INC); \
	}

	#define SET_BOUNDS(RESULT, Option, START, REFERENCE, SCALE) \
	uint64 RESULT = stats.START; \
	{ \
	  const uint64 STATREF = stats.REFERENCE; \
	  const uint64 MINIMUM = opts.Option ## _min_eff; \
	  const uint64 MAXIMUM = MINIMUM * (opts.Option ## _max_eff); \
	  const double RELEFF = (double) (opts.Option ## _rel_eff) * 1e-3; \
	  uint64 INCREASE = uint64(STATREF * RELEFF) + (SCALE); \
	  if (INCREASE < MINIMUM) INCREASE = MINIMUM; \
	  if (INCREASE > MAXIMUM) INCREASE = MAXIMUM; \
	  RESULT += INCREASE; \
	  LOG2(2, "  %s efficiency bounds increased to %lld by a weight %lld", __func__, RESULT, INCREASE); \
	}

	#define SLEEPING(SMONITOR, ENABLED) \
	if (ENABLED) { \
	  Monitor &monitor = (SMONITOR); \
	  assert (monitor.all <= monitor.now); \
	  if (monitor.all) { \
	    LOG2(2, "  %s still sleeping for %d time(s)", __func__, monitor.all); \
	    monitor.all--; \
	    return; \
	  } \
	}

	#define UPDATE_SLEEPER(SMONITOR, SUCCESS) \
	if (opts.SMONITOR ## _sleep_en) { \
	  Monitor &monitor = sleep.SMONITOR; \
	  const uint32 PERIOD = opts.nap; \
	  assert (monitor.all <= monitor.now); \
	  if (SUCCESS) { \
		if (monitor.now) { \
		  LOG2(2, "  %s is waking up after %d passed", __func__, monitor.now); \
		  monitor.now = monitor.all = 0; \
		} else assert (!monitor.all); \
	  } \
	  else { \
		if (monitor.now < PERIOD) { \
		  monitor.now++; \
		  LOG2(2, "  %s sleeping period is increased to %d", __func__, monitor.now); \
		} else monitor.all = monitor.now; \
	  } \
	  assert (monitor.all <= monitor.now); \
	}
}

#endif