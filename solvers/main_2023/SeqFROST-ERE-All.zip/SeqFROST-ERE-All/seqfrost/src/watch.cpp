/***********************************************************************[watch.cpp]
Copyright(c) 2022, Muhammad Osama - Anton Wijs,
Technische Universiteit Eindhoven (TU/e).

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
**********************************************************************************/

#include "solve.hpp"

using namespace SeqFROST;

void Solver::attachBins(BCNF& cnf, const cbucket_t* cs, const bool* deleted, const bool& hasElim)
{
    assert(!wt.empty());
    if (hasElim) {
        const VarState* states = sp->state;
        forall_cnf(cnf, i) {
            const cref_t r = *i;
            if (deleted[r]) continue;
            assert(r < cm.size());
            GET_CLAUSE(c, r, cs);
            if (c.binary()) {
                if (MELTED(states[ABS(c[0])].state)
                    || MELTED(states[ABS(c[1])].state)) {
                    removeClause(c, r);
                }
                else 
                    ATTACH_TWO_WATCHES(r, c);
            }
        }
    }
    else {
        forall_cnf(cnf, i) {
            const cref_t r = *i;
            if (deleted[r]) continue;
            assert(r < cm.size());
            GET_CLAUSE(c, r, cs);
            if (c.binary()) 
                ATTACH_TWO_WATCHES(r, c);
        }
    }
}

void Solver::attachNonBins(BCNF& cnf, const cbucket_t* cs, const bool* deleted, const bool& hasElim)
{
    assert(!wt.empty());
    if (hasElim) {
        const VarState* states = sp->state;
        forall_cnf(cnf, i) {
            const cref_t r = *i;
            if (deleted[r]) continue;
            assert(r < cm.size());
            GET_CLAUSE(c, r, cs);
            if (c.binary()) continue;
            bool removed = false;
            forall_clause(c, k) {
                const uint32 lit = *k;
                if (MELTED(states[ABS(lit)].state)) {
                    removed = true;
                    break;
                }
            }
			if (removed)
				removeClause(c, r);
            else {
                sortClause(c);
                ATTACH_TWO_WATCHES(r, c);
            }
        }
    }
    else {
        forall_cnf(cnf, i) {
            const cref_t r = *i;
            if (deleted[r]) continue;
            assert(r < cm.size());
            GET_CLAUSE(c, r, cs);
            if (c.binary()) continue;
            sortClause(c);
            ATTACH_TWO_WATCHES(r, c);
        }
    }
}

void Solver::attachClauses(BCNF& cnf, const cbucket_t* cs, const bool* deleted, const bool& hasElim)
{
    assert(!wt.empty());
    if (hasElim) {
        const VarState* states = sp->state;
        forall_cnf(cnf, i) {
            const cref_t r = *i;
            if (deleted[r]) continue;
            assert(r < cm.size());
            GET_CLAUSE(c, r, cs);
            bool removed = false;
            forall_clause(c, k) {
                const uint32 lit = *k;
                if (MELTED(states[ABS(lit)].state)) {
                    removed = true;
                    break;
                }
            }
            if (removed)
                removeClause(c, r);
            else {
                if (!c.binary()) 
                    sortClause(c);
                ATTACH_TWO_WATCHES(r, c);
            }
        }
    }
    else {
        forall_cnf(cnf, i) {
            const cref_t r = *i;
            if (deleted[r]) continue;
            assert(r < cm.size());
            GET_CLAUSE(c, r, cs);
            if (!c.binary()) 
                sortClause(c);
            ATTACH_TWO_WATCHES(r, c);
        }
    }
}

void Solver::rebuildWT(const state_t& code)
{
    wt.resize(cnfstats.maxLit);
    PREFETCH_CM(cs, deleted);
    if (PRIORALLBINS(code)) {
        if (PRIORLEARNTBINS(code)) {
            attachBins(learnts, cs, deleted);
            attachBins(orgs, cs, deleted);
        }
        else {
            attachBins(orgs, cs, deleted);
            attachBins(learnts, cs, deleted);
        }
        attachNonBins(orgs, cs, deleted);
        attachNonBins(learnts, cs, deleted);
    }
    else {
        attachClauses(orgs, cs, deleted);
        attachClauses(learnts, cs, deleted);
    }
}

void Solver::sortWT()
{
    WL saved;
    forall_literals(lit) {
        assert(saved.empty());
        WL& ws = wt[lit];
        Watch *j = ws;
        forall_watches(ws, i) {
            const Watch w = *i;
            if (w.binary())
                *j++ = w;
            else 
                saved.push(w);
        }
        ws.resize(uint32(j - ws));
        forall_watches(saved, i) { 
            ws.push(*i);
        }
        saved.clear();
    }
    saved.clear(true);
}

void Solver::detachClauses(const bool& keepbinaries)
{
    forall_literals(lit) {
        WL& ws = wt[lit];
        Watch* j = ws;
        forall_watches(ws, i) {
            const Watch w = *i;
            if (keepbinaries && w.binary()) 
                *j++ = w;
        }
        ws.resize(uint32(j - ws));
    }
}

void Solver::binarizeWT(const bool& keeplearnts)
{
    assert(!LEVEL);
    const state_t* values = sp->value;
    PREFETCH_CM(cs, deleted);
    forall_literals(lit) {
		const state_t litval = values[lit];
		WL& ws = wt[FLIP(lit)];
		Watch* j = ws;
		forall_watches(ws, i) {
			const Watch w = *i;
			if (w.binary()) {
                const cref_t ref = w.ref;
                if (deleted[ref]) continue;
				const uint32 imp = w.imp;
                if (litval > 0 || values[imp] > 0) {
                    if (lit < imp) {
                        GET_CLAUSE(c, ref, cs);
                        removeClause(c, ref);
                    }
                }
                else if (keeplearnts)
                    *j++ = w;  
                else {
                    GET_CLAUSE(c, ref, cs);
                    if (c.original())
                        *j++ = w;                
                }
			}
		}
		ws.resize(uint32(j - ws));
    }
}
