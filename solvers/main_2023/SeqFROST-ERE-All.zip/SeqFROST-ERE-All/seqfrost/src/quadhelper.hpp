﻿/*
	Copyright (C) 2014-2022 Igor van den Hoven ivdhoven@gmail.com
	Copyright (C) 2023 Muhammad Osama Mahmoud
*/

/*
	Permission is hereby granted, free of charge, to any person obtaining
	a copy of this software and associated documentation files (the
	"Software"), to deal in the Software without restriction, including
	without limitation the rights to use, copy, modify, merge, publish,
	distribute, sublicense, and/or sell copies of the Software, and to
	permit persons to whom the Software is furnished to do so, subject to
	the following conditions:

	The above copyright notice and this permission notice shall be
	included in all copies or substantial portions of the Software.

	THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
	EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
	MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
	IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
	CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
	TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
	SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/

/*
	quadhelper 1.2.1.2
*/

#ifndef __QUADHELPER_
#define __QUADHELPER_

#if !defined TERNARYCMP
#define head_branchless_merge(ptd, x, ptl, ptr, cmp)  \
	x = cmp(ptl, ptr);  \
	*ptd = *ptl;  \
	ptl += x;  \
	ptd[x] = *ptr;  \
	ptr += !x;  \
	ptd++;
#else
#define head_branchless_merge(ptd, x, ptl, ptr, cmp)  \
	*ptd++ = cmp(ptl, ptr) ? *ptl++ : *ptr++;
#endif

#if !defined TERNARYCMP
#define tail_branchless_merge(tpd, x, tpl, tpr, cmp)  \
	y = cmp(tpl, tpr);  \
	*tpd = *tpl;  \
	tpl -= !x;  \
	tpd--;  \
	tpd[x] = *tpr;  \
	tpr -= y;
#else
#define tail_branchless_merge(tpd, x, tpl, tpr, cmp)  \
	*tpd-- = !cmp(tpl, tpr) ? *tpl-- : *tpr--;
#endif

#define parity_merge_two(array, swap, x, y, ptl, ptr, pts, cmp)  \
	ptl = array; ptr = array + 2; pts = swap;  \
	head_branchless_merge(pts, x, ptl, ptr, cmp);  \
	*pts = cmp(ptl, ptr) ? *ptl : *ptr;  \
  \
	ptl = array + 1; ptr = array + 3; pts = swap + 3;  \
	tail_branchless_merge(pts, y, ptl, ptr, cmp);  \
	*pts = !cmp(ptl, ptr)  ? *ptl : *ptr;

#define parity_merge_four(array, swap, x, y, ptl, ptr, pts, cmp)  \
	ptl = array + 0; ptr = array + 4; pts = swap;  \
	head_branchless_merge(pts, x, ptl, ptr, cmp);  \
	head_branchless_merge(pts, x, ptl, ptr, cmp);  \
	head_branchless_merge(pts, x, ptl, ptr, cmp);  \
	*pts = cmp(ptl, ptr) ? *ptl : *ptr;  \
  \
	ptl = array + 3; ptr = array + 7; pts = swap + 7;  \
	tail_branchless_merge(pts, y, ptl, ptr, cmp);  \
	tail_branchless_merge(pts, y, ptl, ptr, cmp);  \
	tail_branchless_merge(pts, y, ptl, ptr, cmp);  \
	*pts = !cmp(ptl, ptr)  ? *ptl : *ptr;

#define swap_branchless(pta, swap, x, y, cmp)  \
	y = cmp(pta, pta + 1);  \
	x = !y;  \
	swap = pta[y];  \
	pta[0] = pta[x];  \
	pta[1] = swap;

#endif
