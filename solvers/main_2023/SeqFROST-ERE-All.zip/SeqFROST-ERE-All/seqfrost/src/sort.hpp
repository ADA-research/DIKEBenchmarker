/***********************************************************************[sort.hpp]
Copyright(c) 2022, Muhammad Osama - Anton Wijs,
Technische Universiteit Eindhoven (TU/e).

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
**********************************************************************************/

#ifndef __SORT_
#define __SORT_

#include "key.hpp"
#include "pdqsort.hpp"
#include "fluxsort.hpp"
#include "quadsort.hpp"
#include "wolfsort.hpp"
#include "crumsort.hpp"
#include "crumsortx.hpp"
#include "radixsort.hpp"

#undef QSORTCMP
#undef STABLESORT
#undef INSORT_THR

namespace SeqFROST {

	#define INSORT_THR	24

#if defined(STDSORTSTB)
	#define STABLESORT(PTR, END, LEN, CMP) std::stable_sort((PTR), (END), (CMP))
#else 
	#define STABLESORT(PTR, END, LEN, CMP) quadsort((PTR), (LEN), (CMP))
#endif

	#define SORTCMP(SRC, CMP) \
	{ \
		const auto size = SRC.size() ; \
		if (size && size <= INSORT_THR) \
			insertionSort(SRC.data(), size, CMP); \
		else if (size) \
			std::sort(SRC.data(), SRC.end(), CMP); \
		assert(isSorted(SRC.data(), size, CMP)); \
	}

	//============================//
	//  Sorting Helpers           //
	//============================//
	template<class T, class SZ, class CMP = LESS<T>()>
	inline bool isSorted(T* d, const SZ& size, CMP cmp) 
	{
		for (SZ i = 1; i < size; ++i)
			if (cmp(d[i], d[i - 1])) 
				return false;
		return true;
	}

	template<class T, class SZ>
	inline bool isSorted(T* d, const SZ& size) 
	{
		for (SZ i = 1; i < size; ++i)
			if (d[i] < d[i - 1]) 
				return false;
		return true;
	}

	template<class T>
	inline void cswap(T& x, T& y)
	{
		const T a = MIN(x, y);
		const T b = MAX(x, y);
		x = a, y = b;
	}

	template<class T>
	inline void sort3(T& x, T& y, T& z)
	{
		cswap(y, z);
		cswap(x, z);
		cswap(x, y);
		assert(x <= y && y <= z && x <= z);
	}

	template<class T>
	inline void sort4(T* d)
	{
		cswap(d[0], d[1]);
		cswap(d[2], d[3]);
		cswap(d[0], d[2]);
		cswap(d[1], d[3]);
		cswap(d[1], d[2]);
	}

	template<class T>
	inline void sort5(T* d)
	{
		cswap(d[0], d[1]);
		cswap(d[3], d[4]);
		cswap(d[2], d[4]);
		cswap(d[2], d[3]);
		cswap(d[0], d[3]);
		cswap(d[0], d[2]);
		cswap(d[1], d[4]);
		cswap(d[1], d[3]);
		cswap(d[1], d[2]);
	}

	template<class T>
	inline void sort6(T* d)
	{
		cswap(d[1], d[2]);
		cswap(d[0], d[2]);
		cswap(d[0], d[1]);
		cswap(d[4], d[5]);
		cswap(d[3], d[5]);
		cswap(d[3], d[4]);
		cswap(d[0], d[3]);
		cswap(d[1], d[4]);
		cswap(d[2], d[5]);
		cswap(d[2], d[4]);
		cswap(d[1], d[3]);
		cswap(d[2], d[3]);
	}

	template<class T, class SZ, class CMP>
	inline void insertionSort(T* d, const SZ& size, CMP cmp)
	{
		if (size == 2 && cmp(d[1], d[0]))
			std::swap(d[1], d[0]);
		else if (size > 2) {
			T* end = d + size;
			for (T* i = d + 1; i != end; ++i) {
				T*  j = i, *j_1 = i - 1;
				if (cmp(*j, *j_1)) {
					T tmp = *j;
					do { *j-- = *j_1; } 
					while (j != d && cmp(tmp, *--j_1));
					*j = tmp;
				}
			}
		}
	}

	template<class T, class SZ>
	inline void insertionSort(T* d, const SZ& size)
	{
		const T* end = d + size;
		for (T* i = d + 1; i != end; ++i) {
			T* j = i, * j_1 = i - 1;
			if (*j < *j_1) {
				T tmp = *j;
				do { *j-- = *j_1; } while (j != d && (tmp < *--j_1));
				*j = tmp;
			}
		}
	}

	template <class T, class SZ>
	inline void SORT(T* data, const SZ& size)
	{
		if (size < 2) return;
		else if (size == 2) cswap(data[0], data[1]);
		else if (size == 3) sort3(data[0], data[1], data[2]);
		else if (size == 4) sort4(data);
		else if (size == 5) sort5(data);
		else if (size == 6) sort6(data);
		else if (size <= INSORT_THR)
			insertionSort(data, size);
		else
			crumsortx(data, size);
		assert(isSorted(data, size));
	}

}

#endif