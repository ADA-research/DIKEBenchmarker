/*
	Copyright (C) 2014-2022 Igor van den Hoven ivdhoven@gmail.com
	Copyright (C) 2023 Muhammad Osama Mahmoud
*/

/*
	Permission is hereby granted, free of charge, to any person obtaining
	a copy of this software and associated documentation files (the
	"Software"), to deal in the Software without restriction, including
	without limitation the rights to use, copy, modify, merge, publish,
	distribute, sublicense, and/or sell copies of the Software, and to
	permit persons to whom the Software is furnished to do so, subject to
	the following conditions:

	The above copyright notice and this permission notice shall be
	included in all copies or substantial portions of the Software.

	THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
	EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
	MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
	IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
	CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
	TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
	SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/

/*
	crumsort 1.2.1.2

	Changes to 1.2.1.2:
	- unified data types with templates
	- moved definitions to the header file
	- changed integer comparisons to Booleans
*/

#ifndef __CRUMSORTX_
#define __CRUMSORTX_

typedef bool CMP(const void* a, const void* b);

#ifndef __QUADSORTX_
  #include "quadsortx.hpp"
#endif

#define QUAD_CACHE 262144
#define CRUM_AUX  512
#define CRUM_OUT  96

#define cmp(a,b) (*(a) < *(b))

// The next 4 functions are used for pivot selection
template <class T>
T* crum_binary_median_x(T* pta, T* ptb, size_t len, CMP* cmp)
{
	while (len /= 2)
	{
		if (cmp(pta + len, ptb + len)) pta += len; else ptb += len;
	}
	return !cmp(pta, ptb) ? pta : ptb;
}

template <class T>
T* crum_median_of_cbrt_x(T* array, T* swap, size_t swap_size, size_t nmemb, CMP* cmp)
{
	T* pta, * piv;
	size_t cnt, cbrt, div;

	cbrt = nmemb < 32768 ? 32 : nmemb < 262144 ? 64 : nmemb < 2097152 ? 128 : nmemb < 16777216 ? 256 : 512;

	div = nmemb / cbrt;

	pta = array + nmemb - 1;
	piv = array + cbrt;

	for (cnt = cbrt; cnt; cnt--)
	{
		swap[0] = *--piv; *piv = *pta; *pta = swap[0];

		pta -= div;
	}

	cbrt /= 2;

	quadsort_swap_x(piv, swap, swap_size, cbrt, cmp);
	quadsort_swap_x(piv + cbrt, swap, swap_size, cbrt, cmp);

	return crum_binary_median_x(piv, piv + cbrt, cbrt, cmp);
}

template <class T>
size_t crum_median_of_three_x(T* array, size_t v0, size_t v1, size_t v2, CMP* cmp)
{
	size_t v[3] = { v0, v1, v2 };
	char x, y, z;

	x = !cmp(array + v0, array + v1);
	y = !cmp(array + v0, array + v2);
	z = !cmp(array + v1, array + v2);

	return v[(x == y) + (y ^ z)];
}

template <class T>
T* crum_median_of_nine_x(T* array, size_t nmemb, CMP* cmp)
{
	size_t x, y, z, div = nmemb / 16;

	x = crum_median_of_three_x(array, div * 2, div * 1, div * 4, cmp);
	y = crum_median_of_three_x(array, div * 8, div * 6, div * 10, cmp);
	z = crum_median_of_three_x(array, div * 14, div * 12, div * 15, cmp);

	return array + crum_median_of_three_x(array, x, y, z, cmp);
}

template <class T>
size_t fulcrum_default_partition_x(T* array, T* swap, T* ptx, T* piv, size_t swap_size, size_t nmemb, CMP* cmp)
{
	size_t cnt, val, i, m = 0;
	T* ptl, * ptr, * pta, * tpa;

	if (nmemb <= swap_size)
	{
		cnt = nmemb / 8;

		do for (i = 8; i; i--)
		{
			val = cmp(ptx, piv); swap[-m] = array[m] = *ptx++; m += val; swap++;
		}
		while (--cnt);

		for (cnt = nmemb % 8; cnt; cnt--)
		{
			val = cmp(ptx, piv); swap[-m] = array[m] = *ptx++; m += val; swap++;
		}
		memcpy(array + m, swap - nmemb, sizeof(T) * (nmemb - m));

		return m;
	}

	memcpy(swap, array, 16 * sizeof(T));
	memcpy(swap + 16, array + nmemb - 16, 16 * sizeof(T));

	ptl = array;
	ptr = array + nmemb - 1;

	pta = array + 16;
	tpa = array + nmemb - 17;

	cnt = nmemb / 16 - 2;

	while (1)
	{
		if (pta - ptl - m <= 16)
		{
			if (cnt-- == 0) break;

			for (i = 16; i; i--)
			{
				val = cmp(pta, piv); ptl[m] = ptr[m] = *pta++; m += val; ptr--;
			}
		}
		if (pta - ptl - m > 16)
		{
			if (cnt-- == 0) break;

			for (i = 16; i; i--)
			{
				val = cmp(tpa, piv); ptl[m] = ptr[m] = *tpa--; m += val; ptr--;
			}
		}
	}

	if (pta - ptl - m <= 16)
	{
		for (cnt = nmemb % 16; cnt; cnt--)
		{
			val = cmp(pta, piv); ptl[m] = ptr[m] = *pta++; m += val; ptr--;
		}
	}
	else
	{
		for (cnt = nmemb % 16; cnt; cnt--)
		{
			val = cmp(tpa, piv); ptl[m] = ptr[m] = *tpa--; m += val; ptr--;
		}
	}
	pta = swap;

	for (cnt = 32; cnt; cnt--)
	{
		val = cmp(pta, piv); ptl[m] = ptr[m] = *pta++; m += val; ptr--;
	}
	return m;
}

// As per suggestion by Marshall Lochbaum to improve generic data handling by mimicking dual-pivot quicksort
template <class T>
size_t fulcrum_reverse_partition_x(T* array, T* swap, T* ptx, T* piv, size_t swap_size, size_t nmemb, CMP* cmp)
{
	size_t cnt, val, i, m = 0;
	T* ptl, * ptr, * pta, * tpa;

	if (nmemb <= swap_size)
	{
		cnt = nmemb / 8;

		do for (i = 8; i; i--)
		{
			val = !cmp(piv, ptx); swap[-m] = array[m] = *ptx++; m += val; swap++;
		}
		while (--cnt);

		for (cnt = nmemb % 8; cnt; cnt--)
		{
			val = !cmp(piv, ptx); swap[-m] = array[m] = *ptx++; m += val; swap++;
		}
		memcpy(array + m, swap - nmemb, (nmemb - m) * sizeof(T));

		return m;
	}

	memcpy(swap, array, 16 * sizeof(T));
	memcpy(swap + 16, array + nmemb - 16, 16 * sizeof(T));

	ptl = array;
	ptr = array + nmemb - 1;

	pta = array + 16;
	tpa = array + nmemb - 17;

	cnt = nmemb / 16 - 2;

	while (1)
	{
		if (pta - ptl - m <= 16)
		{
			if (cnt-- == 0) break;

			for (i = 16; i; i--)
			{
				val = !cmp(piv, pta); ptl[m] = ptr[m] = *pta++; m += val; ptr--;
			}
		}
		if (pta - ptl - m > 16)
		{
			if (cnt-- == 0) break;

			for (i = 16; i; i--)
			{
				val = !cmp(piv, tpa); ptl[m] = ptr[m] = *tpa--; m += val; ptr--;
			}
		}
	}

	if (pta - ptl - m <= 16)
	{
		for (cnt = nmemb % 16; cnt; cnt--)
		{
			val = !cmp(piv, pta); ptl[m] = ptr[m] = *pta++; m += val; ptr--;
		}
	}
	else
	{
		for (cnt = nmemb % 16; cnt; cnt--)
		{
			val = !cmp(piv, tpa); ptl[m] = ptr[m] = *tpa--; m += val; ptr--;
		}
	}
	pta = swap;

	for (cnt = 32; cnt; cnt--)
	{
		val = !cmp(piv, pta); ptl[m] = ptr[m] = *pta++; m += val; ptr--;
	}
	return m;
}

template <class T>
void fulcrum_partition_x(T* array, T* swap, T* max, size_t swap_size, size_t nmemb, CMP* cmp)
{
	size_t a_size, s_size;
	T* ptp, piv;

	while (1)
	{
		if (nmemb <= 2048)
		{
			ptp = crum_median_of_nine_x(array, nmemb, cmp);
		}
		else
		{
			ptp = crum_median_of_cbrt_x(array, swap, swap_size, nmemb, cmp);
		}

		piv = *ptp;

		if (max && cmp(max, &piv))
		{
			a_size = fulcrum_reverse_partition_x(array, swap, array, &piv, swap_size, nmemb, cmp);
			s_size = nmemb - a_size;

			if (s_size <= a_size / 16 || a_size <= CRUM_OUT)
			{
				return quadsort_swap_x(array, swap, swap_size, a_size, cmp);
			}
			nmemb = a_size; max = NULL;
			continue;
		}
		*ptp = array[--nmemb];

		a_size = fulcrum_default_partition_x(array, swap, array, &piv, swap_size, nmemb, cmp);
		s_size = nmemb - a_size;

		ptp = array + a_size; array[nmemb] = *ptp; *ptp = piv;

		if (a_size <= s_size / 16 || s_size <= CRUM_OUT)
		{
			if (s_size == 0)
			{
				a_size = fulcrum_reverse_partition_x(array, swap, array, &piv, swap_size, a_size, cmp);
				s_size = nmemb - a_size;

				if (s_size <= a_size / 16 || a_size <= CRUM_OUT)
				{
					return quadsort_swap_x(array, swap, swap_size, a_size, cmp);
				}
				max = NULL;
				nmemb = a_size;
				continue;
			}
			quadsort_swap_x(ptp + 1, swap, swap_size, s_size, cmp);
		}
		else
		{
			fulcrum_partition_x(ptp + 1, swap, max, swap_size, s_size, cmp);
		}

		if (s_size <= a_size / 32 || a_size <= CRUM_OUT)
		{
			return quadsort_swap_x(array, swap, swap_size, a_size, cmp);
		}
		max = ptp;
		nmemb = a_size;
	}
}

template <class T>
void crum_analyze_x(T* array, T* swap, size_t swap_size, size_t nmemb, CMP* cmp)
{
	unsigned char loop, asum, bsum, csum, dsum;
	unsigned int astreaks, bstreaks, cstreaks, dstreaks;
	size_t quad1, quad2, quad3, quad4, half1, half2;
	size_t cnt, abalance, bbalance, cbalance, dbalance;
	T* pta, * ptb, * ptc, * ptd;

	half1 = nmemb / 2;
	quad1 = half1 / 2;
	quad2 = half1 - quad1;
	half2 = nmemb - half1;
	quad3 = half2 / 2;
	quad4 = half2 - quad3;

	pta = array;
	ptb = array + quad1;
	ptc = array + half1;
	ptd = array + half1 + quad3;

	astreaks = bstreaks = cstreaks = dstreaks = 0;
	abalance = bbalance = cbalance = dbalance = 0;

	for (cnt = nmemb; cnt > 132; cnt -= 128)
	{
		for (asum = bsum = csum = dsum = 0, loop = 32; loop; loop--)
		{
			asum += !cmp(pta, pta + 1); pta++;
			bsum += !cmp(ptb, ptb + 1); ptb++;
			csum += !cmp(ptc, ptc + 1); ptc++;
			dsum += !cmp(ptd, ptd + 1); ptd++;
		}
		abalance += asum; astreaks += asum = (asum == 0) | (asum == 32);
		bbalance += bsum; bstreaks += bsum = (bsum == 0) | (bsum == 32);
		cbalance += csum; cstreaks += csum = (csum == 0) | (csum == 32);
		dbalance += dsum; dstreaks += dsum = (dsum == 0) | (dsum == 32);

		if (cnt > 516 && asum + bsum + csum + dsum == 0)
		{
			abalance += 48; pta += 96;
			bbalance += 48; ptb += 96;
			cbalance += 48; ptc += 96;
			dbalance += 48; ptd += 96;
			cnt -= 384;
		}
	}

	for (; cnt > 7; cnt -= 4)
	{
		abalance += !cmp(pta, pta + 1); pta++;
		bbalance += !cmp(ptb, ptb + 1); ptb++;
		cbalance += !cmp(ptc, ptc + 1); ptc++;
		dbalance += !cmp(ptd, ptd + 1); ptd++;
	}

	if (quad1 < quad2) { bbalance += !cmp(ptb, ptb + 1); ptb++; }
	if (quad1 < quad3) { cbalance += !cmp(ptc, ptc + 1); ptc++; }
	if (quad1 < quad4) { dbalance += !cmp(ptd, ptd + 1); ptd++; }

	cnt = abalance + bbalance + cbalance + dbalance;

	if (cnt == 0)
	{
		if (cmp(pta, pta + 1) && cmp(ptb, ptb + 1) && cmp(ptc, ptc + 1))
		{
			return;
		}
	}

	asum = quad1 - abalance == 1;
	bsum = quad2 - bbalance == 1;
	csum = quad3 - cbalance == 1;
	dsum = quad4 - dbalance == 1;

	if (asum | bsum | csum | dsum)
	{
		unsigned char span1 = (asum && bsum) * (!cmp(pta, pta + 1));
		unsigned char span2 = (bsum && csum) * (!cmp(ptb, ptb + 1));
		unsigned char span3 = (csum && dsum) * (!cmp(ptc, ptc + 1));

		switch (span1 | span2 * 2 | span3 * 4)
		{
		case 0: break;
		case 1: quad_reversal_x(array, ptb);   abalance = bbalance = 0; break;
		case 2: quad_reversal_x(pta + 1, ptc); bbalance = cbalance = 0; break;
		case 3: quad_reversal_x(array, ptc);   abalance = bbalance = cbalance = 0; break;
		case 4: quad_reversal_x(ptb + 1, ptd); cbalance = dbalance = 0; break;
		case 5: quad_reversal_x(array, ptb);
			quad_reversal_x(ptb + 1, ptd); abalance = bbalance = cbalance = dbalance = 0; break;
		case 6: quad_reversal_x(pta + 1, ptd); bbalance = cbalance = dbalance = 0; break;
		case 7: quad_reversal_x(array, ptd); return;
		}

		if (asum && abalance) { quad_reversal_x(array, pta); abalance = 0; }
		if (bsum && bbalance) { quad_reversal_x(pta + 1, ptb); bbalance = 0; }
		if (csum && cbalance) { quad_reversal_x(ptb + 1, ptc); cbalance = 0; }
		if (dsum && dbalance) { quad_reversal_x(ptc + 1, ptd); dbalance = 0; }
	}

#ifdef cmp
	cnt = nmemb / 256; // switch to quadsort if at least 50% ordered
#else
	cnt = nmemb / 512; // switch to quadsort if at least 25% ordered
#endif
	asum = astreaks > cnt;
	bsum = bstreaks > cnt;
	csum = cstreaks > cnt;
	dsum = dstreaks > cnt;

#ifndef cmp
	if (quad1 > QUAD_CACHE)
	{
		asum = bsum = csum = dsum = 1;
	}
#endif
	switch (asum + bsum * 2 + csum * 4 + dsum * 8)
	{
	case 0:
		fulcrum_partition_x(array, swap, (T*) NULL, swap_size, nmemb, cmp);
		return;
	case 1:
		if (abalance) quadsort_swap_x(array, swap, swap_size, quad1, cmp);
		fulcrum_partition_x(pta + 1, swap, (T*) NULL, swap_size, quad2 + half2, cmp);
		break;
	case 2:
		fulcrum_partition_x(array, swap, (T*) NULL, swap_size, quad1, cmp);
		if (bbalance) quadsort_swap_x(pta + 1, swap, swap_size, quad2, cmp);
		fulcrum_partition_x(ptb + 1, swap, (T*) NULL, swap_size, half2, cmp);
		break;
	case 3:
		if (abalance) quadsort_swap_x(array, swap, swap_size, quad1, cmp);
		if (bbalance) quadsort_swap_x(pta + 1, swap, swap_size, quad2, cmp);
		fulcrum_partition_x(ptb + 1, swap, (T*) NULL, swap_size, half2, cmp);
		break;
	case 4:
		fulcrum_partition_x(array, swap, (T*) NULL, swap_size, half1, cmp);
		if (cbalance) quadsort_swap_x(ptb + 1, swap, swap_size, quad3, cmp);
		fulcrum_partition_x(ptc + 1, swap, (T*) NULL, swap_size, quad4, cmp);
		break;
	case 8:
		fulcrum_partition_x(array, swap, (T*) NULL, swap_size, half1 + quad3, cmp);
		if (dbalance) quadsort_swap_x(ptc + 1, swap, swap_size, quad4, cmp);
		break;
	case 9:
		if (abalance) quadsort_swap_x(array, swap, swap_size, quad1, cmp);
		fulcrum_partition_x(pta + 1, swap, (T*) NULL, swap_size, quad2 + quad3, cmp);
		if (dbalance) quadsort_swap_x(ptc + 1, swap, swap_size, quad4, cmp);
		break;
	case 12:
		fulcrum_partition_x(array, swap, (T*) NULL, swap_size, half1, cmp);
		if (cbalance) quadsort_swap_x(ptb + 1, swap, swap_size, quad3, cmp);
		if (dbalance) quadsort_swap_x(ptc + 1, swap, swap_size, quad4, cmp);
		break;
	case 5:
	case 6:
	case 7:
	case 10:
	case 11:
	case 13:
	case 14:
	case 15:
		if (asum)
		{
			if (abalance) quadsort_swap_x(array, swap, swap_size, quad1, cmp);
		}
		else fulcrum_partition_x(array, swap, (T*) NULL, swap_size, quad1, cmp);
		if (bsum)
		{
			if (bbalance) quadsort_swap_x(pta + 1, swap, swap_size, quad2, cmp);
		}
		else fulcrum_partition_x(pta + 1, swap, (T*) NULL, swap_size, quad2, cmp);
		if (csum)
		{
			if (cbalance) quadsort_swap_x(ptb + 1, swap, swap_size, quad3, cmp);
		}
		else fulcrum_partition_x(ptb + 1, swap, (T*) NULL, swap_size, quad3, cmp);
		if (dsum)
		{
			if (dbalance) quadsort_swap_x(ptc + 1, swap, swap_size, quad4, cmp);
		}
		else fulcrum_partition_x(ptc + 1, swap, (T*) NULL, swap_size, quad4, cmp);
		break;
	}

	if (cmp(pta, pta + 1))
	{
		if (cmp(ptc, ptc + 1))
		{
			if (cmp(ptb, ptb + 1))
			{
				return;
			}
		}
		else
		{
			blit_merge_block_x(array + half1, swap, swap_size, quad3, quad4, cmp);
		}
	}
	else
	{
		blit_merge_block_x(array, swap, swap_size, quad1, quad2, cmp);

		if (!cmp(ptc, ptc + 1))
		{
			blit_merge_block_x(array + half1, swap, swap_size, quad3, quad4, cmp);
		}
	}
	blit_merge_block_x(array, swap, swap_size, half1, half2, cmp);
}

template <class T>
void crumsortx(T* array, size_t nmemb, CMP* cmp = NULL)
{
	if (nmemb <= 132)
	{
		return quadsortx(array, nmemb, cmp);
	}

	T swap[CRUM_AUX];

	crum_analyze_x(array, swap, CRUM_AUX, nmemb, cmp);
}

template <class T>
void crumsort_swap(T* array, T* swap, size_t swap_size, size_t nmemb, CMP* cmp)
{
	if (nmemb <= 132)
	{
		quadsort_swap_x(array, swap, swap_size, nmemb, cmp);
	}
	else
	{
		crum_analyze_x(array, swap, swap_size, nmemb, cmp);
	}
}

#undef QUAD_CACHE
#undef cmp

#endif
