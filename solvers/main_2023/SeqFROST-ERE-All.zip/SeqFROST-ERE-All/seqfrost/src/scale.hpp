/***********************************************************************[scale.hpp]
Copyright(c) 2022, Muhammad Osama - Anton Wijs,
Technische Universiteit Eindhoven (TU/e).

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
**********************************************************************************/

#ifndef __SCALE_
#define __SCALE_

#include <cmath>
#include <cassert>
#include "datatypes.hpp"

namespace SeqFROST {

	#define		linear(N)			(N)
	#define		quadratic(N)		((N) * (N))
	#define		logn(N)				((uint64)log10((N) + 10))
	#define		nlogn(N)			((N) * logn(N))
	#define		nbylogn(N)			((N) / logn(N))
	#define		nlognlogn(N)		((N) * lognlogn(N))
	#define		nlognlognlogn(N)	((N) * lognlognlogn(N))

	inline uint64 lognlogn(const uint64& n)
	{
		const double val = log10(n + 10);
		return uint64(val * val);
	}

	inline uint64 lognlognlogn(const uint64& n) 
	{
		const double val = log10(n + 10);
		return uint64(val * val * val);
	}

	inline uint64 relscale(const uint64& n, const uint64& increase)
	{
		const uint64 factor = logn(n);
		assert(factor >= 1);
		const uint64 dfactor = factor * factor;
		assert(dfactor >= 1);
		uint64 scaled = dfactor * increase;
		assert(increase <= scaled);
		return scaled;
	}

}

#endif 