/***********************************************************************[simptypes.hpp]
Copyright(c) 2022, Muhammad Osama - Anton Wijs,
Technische Universiteit Eindhoven (TU/e).

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
**********************************************************************************/

#ifndef __SIMP_TYPES_
#define __SIMP_TYPES_

#include "memory.hpp"
#include "datatypes.hpp"
#include "vector.hpp"
#include "sclause.hpp"

namespace SeqFROST {

	constexpr int	 MAXFUNVAR = 12;
	constexpr uint32 FUNTABLEN = 64;  // (1 << (12 - 6))

	extern uint32 orgcore[MAXFUNVAR];

	const uint64 magicnumbers[6] = {
		0xaaaaaaaaaaaaaaaaull, 0xccccccccccccccccull, 0xf0f0f0f0f0f0f0f0ull,
		0xff00ff00ff00ff00ull, 0xffff0000ffff0000ull, 0xffffffff00000000ull,
	};

	struct Occur { uint32 ps, ns; };

	typedef uint64					Fun[FUNTABLEN];
	typedef uint64					sref_t;
	typedef Vector<sref_t, int>		OL;
	typedef Vector<OL>				OT;
	typedef SMM<uint32, sref_t>		SMM_simplifier_t;
	typedef Vector<sref_t>			cnf_refs_t;

	class SCNF : public SMM_simplifier_t {

		cnf_refs_t _refs;

	public:
		inline						SCNF		() { 
			assert(SMM_simplifier_t::bucket() == SIMP_BUCKETSIZE);
            assert(SOLVER_LITSIZE == sizeof(uint32));
            assert(SIMP_CLAUSESIZE == sizeof(SClause)); 
			assert(SIMP_CLAUSEBUCKETS == SIMP_CLAUSESIZE / SIMP_BUCKETSIZE); 
		}
		inline		 void			init        (const sref_t& nCls, const sref_t& nLits) {
			SMM_simplifier_t::init(REGIONBUCKETS(nCls, nLits));
			_refs.reserve((uint32)nCls);
		}
		inline		 void			destroy		()		 { SMM_simplifier_t::dealloc(), _refs.clear(true); }
		inline 		 cnf_refs_t&	refs		()		 { return _refs; }
		inline		 uint32			size		() const { return _refs.size(); }
		inline		 bool			empty		() const { return _refs.empty(); }
		inline 		 sref_t*		end			()		 { return _refs.end(); }
		inline		 sref_t			ref			(const uint32& i)		{ assert(i < _refs.size()); return _refs[i]; }
		inline const sref_t&		ref			(const uint32& i) const { assert(i < _refs.size()); return _refs[i]; }
		inline		 SClause*		clause		(const sref_t& r)		{ return (SClause*)SMM_simplifier_t::address(r); }
		inline const SClause*		clause		(const sref_t& r) const { return (SClause*)SMM_simplifier_t::address(r); }
		inline		 SClause&		operator[]	(const sref_t& r)		{ return (SClause&)SMM_simplifier_t::operator[](r); }
		inline const SClause&		operator[]	(const sref_t& r) const { return (SClause&)SMM_simplifier_t::operator[](r); }
		template <class SRC>
		inline		 SClause*		alloc		(const SRC& src) {
			assert(src.size());
			const sref_t r = SMM_simplifier_t::alloc(SCBUCKETS(src.size()));
            SClause* c = new (clause(r)) SClause(src);
			_refs.push(r);
			return c;
		}
		inline		 sref_t*		alloc		(sref_t& r, const int& nCls, const int& nLits) {
			assert(nLits >= nCls);
			r = SMM_simplifier_t::alloc(REGIONBUCKETS(nCls, nLits));
			const uint32 currSize = _refs.size();
			_refs.expand(nCls + currSize);
			return _refs.data() + currSize;
		}
		inline		 void			migrateTo   (SCNF& dest) {
            SMM_simplifier_t::migrateTo(dest);
            _refs.migrateTo(dest.refs());
        }
		inline		 void			print		(const uint32& off = 0, const bool& p_ref = true) {
			for (uint32 i = off; i < size(); ++i) {
				const sref_t r = ref(i);
				const SClause& c = operator[](r);
				if (c.size()) {
					if (p_ref) printf("c  C(%d, r: %lld)->", i, _refs[i]);
					else printf("c  C(%d)->", i);
					c.print();
				}
			}
		}
		inline		 void			printAdded	(const uint32& off = 0, const bool& p_ref = true) {
			for (uint32 i = off; i < size(); ++i) {
				const sref_t r = ref(i);
				const SClause& c = operator[](r);
				if (c.size() && c.added()) {
					if (p_ref) printf("c  C(%d, r: %lld)->", i, _refs[i]);
					else printf("c  C(%d)->", i);
					c.print();
				}
			}
		}
		inline		 void			printDeleted(const uint32& off = 0, const bool& p_ref = true) {
			for (uint32 i = off; i < size(); ++i) {
				const sref_t r = ref(i);
				const SClause& c = operator[](r);
				if (c.size() && c.deleted()) {
					if (p_ref) printf("c  C(%d, r: %lld)->", i, _refs[i]);
					else printf("c  C(%d)->", i);
					c.print();
				}
			}
		}
	};

	#define forall_occurs(LIST, PTR) \
		for (sref_t* PTR = LIST, *END = LIST.end(); PTR != END; ++PTR)

	#define forall_sclauses(SCNF, PTR) \
		for (sref_t* PTR = SCNF.refs(), *END = SCNF.end(); PTR != END; ++PTR)

}

#endif