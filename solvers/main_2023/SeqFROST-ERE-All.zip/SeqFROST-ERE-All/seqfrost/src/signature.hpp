/***********************************************************************[signature.hpp]
Copyright(c) 2022, Muhammad Osama - Anton Wijs,
Technische Universiteit Eindhoven (TU/e).

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
**********************************************************************************/

#ifndef __SIGNATURE_
#define __SIGNATURE_

#include "constants.hpp"

namespace SeqFROST {

	#define HASH(x)			((x) & 31U)
	#define MAPHASH(x)		(1U << HASH(x))
	#define SIGSUB(A, B)	(!(A & ~B))
	#define SELFSUB(A, B)   SIGSUB(A, (B | ((B & 0xAAAAAAAAU) >> 1) | ((B & 0x55555555U) << 1)))

}

#endif
