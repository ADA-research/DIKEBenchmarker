/***********************************************************************[solve.hpp]
Copyright(c) 2022, Muhammad Osama - Anton Wijs,
Technische Universiteit Eindhoven (TU/e).

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
**********************************************************************************/

#ifndef __SOLVE_
#define __SOLVE_

#include "map.hpp"
#include "walk.hpp"
#include "heap.hpp"
#include "queue.hpp"
#include "model.hpp"
#include "proof.hpp"
#include "level.hpp"
#include "limit.hpp"
#include "timer.hpp"
#include "dimacs.hpp"
#include "random.hpp"
#include "restart.hpp"
#include "options.hpp"
#include "simptypes.hpp"
#include "solvetypes.hpp"
#include "statistics.hpp"
#include "heuristics.hpp"

namespace SeqFROST {

	#define NOT_UNSAT	cnfstate

	#define UNSAT		(!cnfstate)

	#define SAT			(cnfstate & SAT_M)

	#define UNSOLVED	(cnfstate & UNSOLVED_M)

	#define SET_SAT		(cnfstate = SAT_M)

	#define SET_UNSAT	(cnfstate = UNSAT_M)

	#define RESETSTATE	(cnfstate = UNSOLVED_M)

	#define INTERRUPTED	interrupted

	#define LEVEL		decisionlevel

	#define INCLEVEL(LIT) { decisionlevel = dlevel.size(); \
							dlevel.push(Level(trail.size(), LIT)); }

	#define EXHAUSTED (INTERRUPTED || (opts.boundsearch_en && \
									  (stats.conflicts >= opts.conflict_out || \
									   stats.decisions.single >= opts.decision_out))) \

	#define TARGETING	(stable || opts.targetonly_en)

	#define HEAPSCORES	(decheuristic ? chb.scores : vsids.scores)

	#define DECISIONHEAP (decheuristic ? chbheap : vsidsheap)


	class Solver {
	protected:
		Formula			formula;
		Timer			timer;
		CMM				cm;
		WT				wt;
		SP				*sp;
		Limit			limit;
		Last			last;
		Statistics		stats;
		Sleep			sleep;
		BCNF			orgs;
		BCNF			learnts;
		BCNF			reduced;
		Clause			subbin;
		MAB				mab;
		CHB				chb;
		VSIDS			vsids;
		Queue			vmtf;
		Map				vmap;
		Lits			learntC;
		Bumps			bumps;
		DecHeap			vsidsheap;
		DecHeap			chbheap;
		Levels			dlevel;
		VarSchedule		vschedule;
		ClsSchedule		scheduled;
		Vector<Occur>	occurs;
		Vector<DWatch>	dwatches;
		Vector<WOL>		wot;
		Vector<BOL>		bot;	
		uVec			lbdlevels;
		uVec			eligible;
		uVec			probes;
		uVec			trail;
		uVec			vorg;
		uVec			vhist;
		uVec			analyzed;
		uVec			minimized;
		uVec			shrinkable;
		LBDRestart		lbdrest;
		LUBYRestart		lubyrest;
		Random			random;
		Walk			tracker;
		uint64			bumped;
		cref_t			conflict;
		cref_t			ignore;
		size_t			tablerowlen;
		string			tablerow;
		uint32			decisionlevel;
		int				decheuristic;
		bool			interrupted;
		bool			incremental;
		bool			stable;
		bool			probed;

	public:

		Option			opts;
		Model			model;
		Proof			proof;
		state_t			cnfstate;
		
						~Solver				() { }
						Solver				(const string& path);
		inline void		bumpShrunken		(Clause& c);						
		inline void		bumpClause			(Clause& c);
		inline int		calcLBD				(Clause& c);
		inline int		removeRooted		(Clause& c, const uint32* levels);
		inline void		removeSubsumed		(Clause& c, const cref_t& cref, Clause* subsuming);
		inline bool		subsumeCheck		(Clause* subsuming, uint32& self, const state_t* marks);
		inline state_t	subsumeClause		(Clause& c, const cbucket_t* cs, const bool* deleted, const VarState* states, const cref_t& cref);
		inline void	    strengthenOTF		(Clause& c, const cref_t& ref, const uint32& self);
		inline void		strengthen			(Clause& c, const uint32& self);
		inline state_t	sortClause			(Clause& c, const int& start, const int& size, const bool& satonly);
		inline void		moveClause			(cref_t& r, CMM& newBlock, const cbucket_t* cs);
		inline void		moveWatches			(WL& ws, CMM& newBlock, const cbucket_t* cs);
		inline uint32	minReachable		(WL& ws, DFS* dfs, const DFS& node);
		inline bool		depFreeze			(const uint32& cand, const cbucket_t* cs, const state_t* values, state_t* frozen, uint32*& stack, WL& ws);
		inline void		MDMAssume			(const state_t* values, const cbucket_t* cs, state_t* frozen, uint32*& tail);
		inline bool		valid				(const state_t* values, const cbucket_t* cs, WL& ws);
		inline void		recycleWL			(const uint32& lit, const cbucket_t* cs, const bool* deleted);
		inline bool		findBinary			(uint32 first, uint32 second, const cbucket_t* cs);
		inline bool		findTernary			(uint32 first, uint32 second, uint32 third, const cbucket_t* cs);
		inline void		analyzeLit			(const uint32& lit, int& track, int& size);
		inline uint32	analyzeReason		(const cref_t& ref, const uint32& lit);
		inline bool		analyzeReason		(const cref_t& ref, const uint32& parent, int& track);
		inline bool		isBinary			(const cref_t& r, uint32& first, uint32& second);
		inline uint32	propAutarkClause	(const bool& add, const cref_t& ref, Clause& c, const state_t* values, state_t* autarkies);
		inline bool		propProbe			(const uint32& assign);
		inline bool		propVivify			(const uint32& assign, const cbucket_t* cs, const bool* deleted);
		inline bool		propBinary			(const uint32& assign);
		inline void		cancelAssign		(const uint32& lit);
		inline void		cancelAutark		(const bool& add, const uint32& lit, state_t* autarkies);
		inline bool		canDecompose		(const bool& first);
		inline void		pumpFrozenHeap		(const uint32& lit);
		inline void		pumpFrozenQue		(const uint32& lit);
		inline void		bumpReason			(const uint32& lit);
		inline void		bumpReasons			(const uint32& lit);
		inline void		bumpReasons			();
		inline void		bumpAnalyzed		();
		inline void		savePhases			();
		inline void		varOrgPhase			();
		inline void		varInvPhase			();
		inline void		varFlipPhase		();
		inline void		varBestPhase		();
		inline void		varWalkPhase		();
		inline void		varRandPhase		();
		inline uint32	where				();
		inline int		calcLBD				();
		inline bool		canVivify			();
		inline uint32	nextProbe			();
		inline void		nointerrupt			() { 
			interrupted = false;
		}
		inline void		interrupt			() { 
			interrupted = true;
		}	
		inline bool		canSimplify			() {
			if (!opts.simplify_en) return false;
			if (!ORIGINALS) return false;
			if (last.simplify.reduces > stats.reduces) return false;
			if (limit.simplify > stats.conflicts) return false;
			if (sp->simplified >= opts.simplify_min) return true;
			return ((stats.shrunken - last.shrink.removed) > (opts.simplify_min << 4));
		}
		inline bool		canMMD				() 
		{
			if (!opts.mdm_rounds) return false;
			assert(trail.size() <= cnfstats.maxVar); 
			const bool enough = (cnfstats.maxVar - trail.size()) > last.mdm.unassigned;
			const bool rounds = last.mdm.rounds;
			if (enough && !rounds && stats.conflicts >= limit.mdm) {
				last.mdm.rounds = opts.mdm_rounds;
				INCREASE_LIMIT(mdm, stats.mdm.calls, nlogn, true);
			}
			return enough && rounds;
		}
		inline bool		canRestart			()
		{
			if (!LEVEL) return false;
			if (stats.conflicts < limit.restart.conflicts) return false;
			vibrate();
			if (stable) return lubyrest;
			return lbdrest.restart(stable);
		}
		inline void		rootify				() {
			assert(UNSOLVED);
			assert(sp->propagated == trail.size());
			backtrack();
			if (BCP()) learnEmpty();
		}
		inline bool		retrail				() {
			assert(!LEVEL);
			sp->propagated = 0;
			if (BCP()) {
				learnEmpty();
				return true;
			}
			return false;
		}
		inline void		initQueue			() {
			LOGN2(2, " Initializing VMFQ Queue with %d variables..", cnfstats.maxVar);
			vmtf.reserve(cnfstats.maxVar);
			forall_variables(v) { 
				vmtf.insert(v);
				vmtf.update(v, (bumps[v] = ++bumped));
			}
			LOGDONE(2, 4);
		}
		inline void		initHeap			() {
			LOGN2(2, " Initializing variable heap(s) with %d variables..", cnfstats.maxVar);
			vsidsheap.reserve(cnfstats.maxVar);
			chbheap.reserve(cnfstats.maxVar);
			forall_variables(v) {
				vsidsheap.insert(v);
				chbheap.insert(v);
			}
			LOGDONE(2, 5);
		}
		inline void		initVars			() {
			LOGN2(2, " Initializing original variables array with %d variables..", cnfstats.maxVar);
			vorg.resize(cnfstats.maxVar + 1);
			uint32* d = vorg;
			*d = 0;
			forall_variables(v) { d[v] = v; }
			LOGDONE(2, 5);
		}
		inline void		updateQueue			() {
			const uint32 last = vmtf.last();
			vmtf.update(last, bumps[last]);
		}
		inline void		updateHeap			() {
			DecHeap& heap = DECISIONHEAP;
			const VarState* states = sp->state;
			forall_variables(v) {
				if (!states[v].state && !heap.has(v))
					heap.insert(v);
			}
		}
		inline void		updateCHB			() {
			const VarState* states = sp->state;
			uint64* conflicts = chb.conflicts.data();
			forall_vector(uint32, analyzed, a) {
				if (!states[*a].state)
					conflicts[*a] = stats.conflicts;
			}
		}
		inline void		learnEmpty			() {
			if (opts.proof_en) 
				proof.addEmpty();
			SET_UNSAT;
		}
		inline void		clearLevels			() {
			forall_vector(uint32, lbdlevels, dl) {
				sp->state[*dl].dlcount = 0;
			}
			lbdlevels.clear();
		}
		inline void		clearMinimized		() {
			forall_vector(uint32, minimized, v) {
				sp->seen[*v] = 0;
			}
			minimized.clear();
		}
		inline void		clearAnalyzed		() {
			forall_vector(uint32, analyzed, a) {
				sp->seen[*a] = 0;
			}
			analyzed.clear();
		}
		inline void		clearVivify			() {
			forall_vector(uint32, analyzed, a) {
				CHECKLIT(*a);
				sp->seen[ABS(*a)] = 0;
			}
			analyzed.clear();
			learntC.clear();
		}
		inline void		clearFrozen			() {
			assert(sp->stacktail - sp->tmpstack <= cnfstats.maxVar);
			state_t* frozen = sp->frozen;
			for (uint32* i = sp->tmpstack, *end = sp->stacktail; end != i; ++i)
				frozen[*i] = 0;

			assert(_checkfrozen(sp->frozen, cnfstats.maxVar));
		}
		inline void		clearMDM			() {
			assert(_checkMDM(sp->frozen, trail, sp->propagated));
			state_t* seen = sp->seen;
			for (uint32* i = trail + sp->propagated, *end = trail.end(); i != end; ++i)
				seen[ABS(*i)] = 0;

			assert(_checkseen(sp->seen, cnfstats.maxVar));
			assert((sp->stacktail - sp->tmpstack) <= (cnfstats.maxVar - last.mdm.decisions));

			clearFrozen();
		}
		inline void		clearMapFrozen		() {
			if (*orgcore < UNDEF_VAR) {
				for (int i = 0; i < MAXFUNVAR; ++i) {
					assert(orgcore[i] <= cnfstats.maxVar);
					sp->marks[orgcore[i]] = UNDEF_VAL;
				}
				*orgcore = UNDEF_VAR;
			}
		}
		inline void		markLit				(const uint32& lit) { CHECKLIT(lit); sp->marks[ABS(lit)] = SIGN(lit); }
		inline void		unmarkLit			(const uint32& lit) { CHECKLIT(lit); sp->marks[ABS(lit)] = UNDEF_VAL; }
		inline bool		active				(const uint32& lit) const { CHECKLIT(lit); return !sp->state[ABS(lit)].state; }
		inline bool		inactive			(const uint32& lit) const { CHECKLIT(lit); return sp->state[ABS(lit)].state; }
		inline bool		subsumed			(const uint32& lit) const { CHECKLIT(lit); return sp->marks[ABS(lit)] == SIGN(lit); }
		inline bool		notsubsumed			(const uint32& lit) const { CHECKLIT(lit); return sp->marks[ABS(lit)] ^ SIGN(lit); }
		inline bool		selfsubsumed		(const uint32& lit) const { CHECKLIT(lit); return sp->marks[ABS(lit)] == !SIGN(lit); }
		inline uint32	l2dl				(const uint32& lit) const { CHECKLIT(lit); return sp->level[ABS(lit)]; }
		inline cref_t	l2r					(const uint32& lit) const { CHECKLIT(lit); return sp->source[ABS(lit)]; }
		inline state_t	l2marker			(const uint32& lit) const { CHECKLIT(lit); return sp->marks[ABS(lit)]; }
		inline state_t	l2value				(const uint32& lit) const { CHECKLIT(lit); return sp->value[lit]; }
		inline state_t	unassigned			(const uint32& lit) const { CHECKLIT(lit); return UNASSIGNED(sp->value[lit]); }
		inline bool		isFalse				(const uint32& lit) const { CHECKLIT(lit); return !sp->value[lit]; }
		inline bool		isTrue				(const uint32& lit) const 
		{ 
			CHECKLIT(lit);
			state_t val = sp->value[lit];
			return val && !UNASSIGNED(val);
		}	
		inline void		enqueueDecision		(const uint32& lit) 
		{
			CHECKLIT(lit);
			assert(cnfstats.unassigned);

			INCLEVEL(lit);
			enqueue(lit, LEVEL);
		}
		inline void		enqueueUnit			(const uint32& lit) 
		{
			CHECKLIT(lit);
			assert(active(lit));
			const uint32 v = ABS(lit);
			learnUnit(lit, v);
			sp->level[v] = 0;
			sp->value[lit] = 1;
			sp->value[FLIP(lit)] = 0;
			trail.push(lit);
			assert(cnfstats.unassigned);
			cnfstats.unassigned--;
#ifdef LOGGING
			LOGNEWLIT(3, UNDEF_REF, lit);
#endif
			if (wt.size()) {
				WL& ws = wt[lit];
				if (ws.size()) {
#if defined(_WIN32)
					PreFetchCacheLine(PF_TEMPORAL_LEVEL_1, &ws[0]);
#else
					__builtin_prefetch(&ws[0], 0, 1);
#endif
				}
			}
		}
		inline void		enqueue				(const uint32& lit, const uint32& level = 0, const cref_t src = UNDEF_REF) 
		{
			CHECKLIT(lit);
			CHECKLEVEL(level);
			assert(unassigned(lit));
			const uint32 v = ABS(lit);
			if (!probed) sp->phase[v].saved = SIGN(lit);
			sp->source[v] = src;
			sp->level[v] = level;
			sp->value[lit] = 1;
			sp->value[FLIP(lit)] = 0;
			sp->trailpos[v] = trail.size();
			trail.push(lit);
			assert(cnfstats.unassigned);
			cnfstats.unassigned--;
			if (!level) learnUnit(lit, v);
#ifdef LOGGING
			LOGNEWLIT(4, src, lit);
#endif
			assert(wt.size());
			WL& ws = wt[lit];
			if (ws.size()) {
#if defined(_WIN32)
				PreFetchCacheLine(PF_TEMPORAL_LEVEL_1, &ws[0]);
#else
				__builtin_prefetch(&ws[0], 0, 1);
#endif
			}
		}
		inline void		detachWatch			(const uint32& lit, const cref_t& ref) 
		{
			CHECKLIT(lit);
			assert(ref < UNDEF_REF);
			WL& ws = wt[lit];
			if (ws.empty()) return;
			Watch *j = ws;
			forall_watches(ws, i) {
				const Watch w = *i;
				if (NEQUAL(w.ref, ref))
					*j++ = w;
			}
			assert(j + 1 == ws.end());
			ws.resize(uint32(j - ws));
		}
		inline uint32	forcedLevel			(const uint32& lit, Clause& c)
		{
			CHECKLIT(lit);
			uint32 flevel = 0;
			forall_clause(c, k) {
				const uint32 other = *k;
				if (NEQUAL(other, lit)) {
					assert(!unassigned(other));
					const uint32 otherlevel = l2dl(other);
					if (otherlevel > flevel) 
						flevel = otherlevel;
				}
			}
			CHECKLEVEL(flevel);
			return flevel;
		}
		inline void		learnUnit			(const uint32& lit, const uint32& v)
		{
			if (opts.proof_en) proof.addUnit(lit);
			assert(ABS(lit) == v);
			markFrozen(v);
		}		
		inline void		varBumpQueue		(const uint32& v) 
		{
			CHECKVAR(v);
			if (!vmtf.next(v)) return;
			vmtf.toFront(v);
			assert(bumped && bumped < UINT64_MAX);
			bumps[v] = ++bumped;
			if (UNASSIGNED(sp->value[V2L(v)])) vmtf.update(v, bumps[v]);
		}
		inline void		varBumpQueueNU		(const uint32& v) 
		{
			CHECKVAR(v);
			if (!vmtf.next(v)) return;
			assert(bumped && bumped < UINT64_MAX);
			vmtf.toFront(v);
			bumps[v] = ++bumped;
#ifdef LOGGING
			LOG2(4, " Variable %d moved to queue front & bumped to %lld", v, bumped);
#endif
		}
		inline void		markFrozen			(const uint32& v)
		{
			CHECKVAR(v);
			sp->state[v].state = FROZEN_M;
			cnfstats.maxFrozen++;
		}
		inline void		markEliminated		(const uint32& v) 
		{
			CHECKVAR(v);
			assert(!sp->state[v].state);
			sp->state[v].state = MELTED_M;
			assert(cnfstats.unassigned);
			cnfstats.unassigned--;
		}
		inline void		markSubstituted		(const uint32& v) 
		{
			CHECKVAR(v);
			assert(!sp->state[v].state);
			sp->state[v].state = SUBSTITUTED_M;
			assert(cnfstats.unassigned);
			cnfstats.unassigned--;
			cnfstats.maxSubstituted++;
		}
		void			shrinkClause		(const cref_t& r, const uint32* levels, const state_t* values);
		void			shrinkClause		(Clause& c, const int& remLits);
		void			removeClause		(Clause& c, const cref_t& cref);
		void			sortClause			(Clause& c);
		bool			hyper3Resolve		(Clause& pos, Clause& neg, const uint32& p);
		uint32			hyper2Resolve		(uint32* lits, const int csize, const uint32& lit);
		bool			vivifyClause		(const cref_t& cref);
		bool			vivifyAnalyze		(Clause& cand, bool& original);
		bool			vivifyLearn			(Clause& cand, const cref_t& cref, const int& nonFalse, const bool& original);
		void			addClause			(SClause& src);
		cref_t			addClause			(const Lits& src, const bool& learnt);
		void			addClause			(const cref_t& cref, Clause& c, const bool& learnt);
		bool			makeClause			(Lits& c, Lits& org, char*& str);
		void			backtrack			(const uint32& jmplevel = 0);
		void			map					(const bool& sigmified = false);
		void			recycle				(CMM& new_cm);
		void			recycleWT			(const cbucket_t* cs, const bool* deleted);
		void			filter				(BCNF& cnf, const bool* deleted);
		void			filter				(BCNF& cnf, CMM& new_cm, const cbucket_t* cs, const bool* deleted);
		void			histBins			(BCNF& cnf);
		void			shrink				(BCNF& cnf);
		void			shrinkTop			(BCNF& cnf);
		void			sortVivify			(BCNF& cnf);
		void			scheduleForward		(BCNF& cnf, const cbucket_t* cs, const bool* deleted);
		void			scheduleVivify		(BCNF& cnf, const bool& tier2, const bool& learnt);
		void			histCNF				(BCNF& cnf, const bool& reset = false);
		void			attachBins			(BCNF& cnf, const cbucket_t* cs, const bool* deleted, const bool& hasElim = false);
		void			attachNonBins		(BCNF& cnf, const cbucket_t* cs, const bool* deleted, const bool& hasElim = false);
		void			attachClauses		(BCNF& cnf, const cbucket_t* cs, const bool* deleted, const bool& hasElim = false);
		bool			substitute			(BCNF& cnf, uint32* smallests);
		void			attachTernary		(BCNF& cnf, state_t* use, const cbucket_t* cs, const bool* deleted);
		void			scheduleTernary		(state_t* use);
		uint32			autarkReasoning		(state_t* autarkies);
		uint32			useAutarky			(state_t* autarkies);
		uint32			propAutarky			(const state_t* values, state_t* autarkies);
		void			vivifying			(const state_t& type);
		void			ternarying			(const uint64& resolvents_limit, const uint64& checks_limit);
		void			transiting			(const uint32& src, const uint64& limit, uint64& removed, uint32& units);
		void			ternaryResolve		(const uint32& p, const uint64& limit);
		void			subsumeLearnt		(const cref_t& lref);
		uint32			makeAssign			(const uint32& v, const bool& tphase = false);
		bool			minimize			(const uint32& lit, const int& depth = 0);
		void			rebuildWT			(const state_t& priorbins = 0);
		void			binarizeWT			(const bool& keeplearnts);
		void			detachClauses		(const bool& keepbinaries);
		void			decompose			(const bool& first);
		void			shrinkTop			(const bool& conditional);
		void			newHyper3			(const bool& learnt);
		uint32			nextHeap			(DecHeap& heap);
		uint32			nextQueue			();
		void			newHyper2			();
		bool			shrink				();
		bool			decompose			();
		void			debinary			();
		void			ternary				();
		void			transitive			();
		void			vivify				();
		void			sortWT				();
		void			pumpFrozen			();
		void			allocSolver			();
		void			initLimits			();
		void			initSolver			();
		void			killSolver			();
		void			markReasons		    ();
		void			unmarkReasons	    ();
		void			recycle				();
		void			reduce				();
		void			reduceLearnts		();
		void			rephase				();
		void			autarky				();
		void			filterAutarky		();
		void			forward				();
		void			forwardAll			();
		void			filterOrg			();
		void			minimize			();
		void			minimizebin			();
		void			vibrate				();
		void			updateModeLimit		();
		void			updateUnstableLimit	();
		void			stableMode			();
		void			unstableMode		();
		void			restart				();
		void			probe				();
		void			failing				();
		void			scheduleProbes		();
		uint32			reuse				();
		cref_t			learn				();
		void			analyze				();
		bool			finduip				();
		bool			chronoAnalyze		();
		bool			chronoHasRoot		();
		bool			BCPVivify			();
		bool			BCPProbe			();
		bool			BCP					();
		void			MDMInit				();
		void			MDM					();
		void			decide				();
		void			report				();
		void			wrapup				();
		void			parser				();
		void			solve				();

		//==========================================//
		//                Simplifier                //
		//==========================================//
	protected:
		uVec	elected;
		SCNF	scnf;
		OT		ot;
		uint32	multiplier;
		int		phase;
		int		numforced;
		int		simpstate;
		bool	mapped;

	public:

		inline void		resizeCNF			() {
			int times = phase + 1;
			if (times > 1 && times != opts.phases && (times % opts.collect_freq) == 0)
				shrinkSimp();
		}
		inline void		initSimp			() {
			phase = multiplier = numforced = 0;
			simpstate = AWAKEN_SUCC;
		}
		inline void		filterElected		() {
			uint32* i = elected, *j = i; 
			uint32* end = elected.end();
			while (i != end) {
				const uint32 x = *i++;
				if (x && !sp->state[x].state) 
					*j++ = x;
			}
			elected.resize(uint32(j - elected));
		}
		inline void		countMelted			() {
			cnfstats.nDeletedVarsAfter = 0;
			forall_variables(v) {
				if (MELTED(sp->state[v].state))
					cnfstats.nDeletedVarsAfter++;
			}
			assert(cnfstats.nDeletedVarsAfter >= cnfstats.maxMelted);
			cnfstats.nDeletedVarsAfter -= cnfstats.maxMelted;
			cnfstats.maxMelted += cnfstats.nDeletedVarsAfter;
		}
		inline void		countFinal			() {
			countMelted();
			countAll();
			cnfstats.nClauses = cnfstats.nClausesAfter;
			cnfstats.nLiterals = cnfstats.nLiteralsAfter;	
		}
		inline void		countAll			() {
			cnfstats.nClausesAfter = 0;
			cnfstats.nLiteralsAfter = 0;
			forall_sclauses(scnf, i) {
				const SClause& s = scnf[*i];
				if (s.original() || s.learnt()) {
					cnfstats.nClausesAfter++;
					cnfstats.nLiteralsAfter += s.size();
				}
			}
		}
		inline void		countCls			() {
			cnfstats.nClausesAfter = 0;
			forall_sclauses(scnf, i) {
				const SClause& s = scnf[*i];
				if (s.original() || s.learnt())
					cnfstats.nClausesAfter++;
			}
		}
		inline void		countLits			() {
			cnfstats.nLiteralsAfter = 0;
			forall_sclauses(scnf, i) {
				const SClause& s = scnf[*i];
				if (s.original() || s.learnt())
					cnfstats.nLiteralsAfter += s.size();
			}
		}
		inline void		evalReds			() {
			cnfstats.nClausesAfter = 0;
			cnfstats.nLiteralsAfter = 0;
			forall_sclauses(scnf, i) {
				const SClause& s = scnf[*i];
				if (s.original() || s.learnt()) {
					cnfstats.nClausesAfter++;
					cnfstats.nLiteralsAfter += s.size();
				}
			}
			countMelted();
		}
		inline void		logReductions		() {
			int64 varsRemoved	= int64(cnfstats.nDeletedVarsAfter) + numforced;
			int64 clsRemoved	= int64(cnfstats.nClauses)	- cnfstats.nClausesAfter;
			int64 litsRemoved	= int64(cnfstats.nLiterals)	- cnfstats.nLiteralsAfter;
			const char *header	= "  %s%-10s  %-10s %-10s %-10s%s";
			LOG1(header, CREPORT, " ", "Variables", "Clauses", "Literals", CNORMAL);
			const char* rem = "  %s%-10s: %s%-9lld  %c%-8lld  %c%-8lld%s";
			const char* sur = "  %s%-10s: %s%-9d  %-9d  %-9d%s";
			LOG1(rem, CREPORT, "Removed", CREPORTVAL, 
				-varsRemoved,
				clsRemoved < 0 ? '+' : '-', abs(clsRemoved), 
				litsRemoved < 0 ? '+' : '-', abs(litsRemoved), CNORMAL);
			LOG1(sur, CREPORT, "Survived", CREPORTVAL,
				ACTIVEVARS,
				cnfstats.nClausesAfter,
				cnfstats.nLiteralsAfter, CNORMAL);
		}
		inline void		removeClause		(SClause& c)
		{
			if (!c.deleted()) {
				c.markDeleted();
				if (opts.proof_en)
					proof.deleteClause(c);
			}
		}
		inline void		bumpShrunken		(SClause& c)
		{
			assert(c.learnt());
			assert(c.size() > 1);
			const int old_lbd = c.lbd();
			if (old_lbd <= opts.lbd_tier1) return; // always keep Tier1 value
			const int size = c.size() - 1;
			int new_lbd = MIN(size, old_lbd);
			if (new_lbd >= old_lbd) return;
			c.set_lbd(new_lbd);
			c.set_usage(USAGET3);
			LOGCLAUSE(4, c, " Bumping shrunken clause with (lbd:%d, usage:%d) ", new_lbd, c.usage());
		}
		inline void		addResolvent		(const Lits& resolvent, const sref_t& ref);
		inline void		resolve				(const uint32& x, Lits& out_c, const int& nAddedCls, const int& nAddedLits);
		inline void		resolveCore			(const uint32& x, Lits& out_c, const int& nAddedCls, const int& nAddedLits);
		inline void		substitute			(const uint32& x, Lits& out_c, const int& nAddedCls, const int& nAddedLits);
		inline bool		propClause			(const state_t* values, const uint32& lit, SClause& c);
		inline bool		depFreeze			(OL& ol, Occur* occs, state_t* frozen, uint32*& tail, const uint32& cand, const uint32& pmax, const uint32& nmax);
		inline bool		checkMem			(const string& name, const size_t& size);
		void			strengthen			(SClause& c, const uint32& me);
		void			extract				(BCNF& cnf);
		void			histCNF				(SCNF& cnf, const bool& reset = false);
		void			reduceOL			(OL& ol);
		void			createOT			(const bool& reset = true);
		void			newBeginning		();
		void			shrinkSimp			();
		void			simplifying			();
		void			simplify			();
		void			awaken				();
		bool			LCVE				();
		bool			prop				();
		void			VE					();
		void			SUB					();
		void			ERE					();
		void			BCE					();
		void			sortOT				();
		void			reduceOT			();

		//==========================================//
		//             Local search                 //
		//==========================================//
		inline bool		popUnsat			(const uint32& infoidx, const uint32& unsatidx, Vector<CINFO>& cinfo);
		inline void		saveTrail			(const state_t* values, const bool& keep);
		inline void		saveAll				(const state_t* values);
		inline uint32	breakValue			(const uint32& lit);
		inline void		makeClauses			(const uint32& lit);
		inline void		breakClauses		(const uint32& lit);
		inline void		walkassign			();
		uint32			promoteLit			();
		uint32			ipromoteLit			();
		bool			walkschedule		();
		void			walkinit			();
		void			walkstep			();
		void			walkstop			();
		void			walking				();
		void			walk				();

		//==========================================//
		//          Incremental Solving             //
		//==========================================//
	protected:

		Vector<state_t>		ifrozen;
		Vector<state_t>		ivalue;
		Vector<state_t>		imarks;
		Vector<VarState>	ivstate;
		Lits			iconflict;
		uVec			ilevel;
		uVec			assumptions;

	public:
						Solver				();
		void			iunassume			();
		void			iallocSpace			();
		uint32			iadd			    ();
		void			idecide				();
		void			ianalyze			(const uint32& failed);
		bool			itoClause			(Lits& c, Lits& org);
		void			iassume				(Lits& assumptions);
		void			isolve				(Lits& assumptions);
		bool		    ifailed             (const uint32& v);
		void		    ifreeze             (const uint32& v);
		void		    iunfreeze           (const uint32& v);
		bool		    ieliminated         (const uint32& v);
		inline uint32   imap                (const uint32& v) const {
			assert(v && v < UNDEF_VAR);
			assert(model.lits.size() > v);
			return model.lits[v];
		}
		inline bool		iassumed            (const uint32& v) const {
			CHECKVAR(v);
			return incremental && ifrozen[v];
		}

		//==========================================//
		//			       Printers                 //
		//==========================================//
		void			printStats			(const bool& printing = true, const byte_t& type = ' ', const char* color = CNORMAL);
		void			printOrgStats		(const byte_t& type = ' ', const char* color = CNORMAL);
		void			printVars			(const uint32* arr, const uint32& size, const state_t& type = 'x');
		void			printClause			(const Lits& c);
		void			printTrail			(const uint32& off = 0);
		void			printCNF			(const BCNF& cnf, const int& off = 0);
		void			printOL				(const OL& list);
		void			printOL				(const uint32& lit);
		void			printOccurs			(const uint32& v);
		void			printWL				(const uint32& lit, const bool& bin = 0);
		void			printWL				(const WL& ws, const bool& bin = 0);
		void			printWatched		(const uint32& v);
		void			printBinaries		(const uint32& v);
		void			printSortedStack	(const int& tail);
		void			printTable			();
		void			printWT				();
		void			printOT				();
		void			printHeap			();
		void			printSource			();
		void			printLearnt			();
		
	};

	extern Solver* solver;

}

#endif 