/***********************************************************************[solvetypes.hpp]
Copyright(c) 2022, Muhammad Osama - Anton Wijs,
Technische Universiteit Eindhoven (TU/e).

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
**********************************************************************************/

#ifndef __SOLVER_TYPES_
#define __SOLVER_TYPES_

#include "memory.hpp"
#include "vector.hpp"
#include "clause.hpp"
#include "space.hpp"
#include "watch.hpp"
#include "heap.hpp"

namespace SeqFROST {
	
    typedef Vector<Watch> WL;
    typedef Vector<WL>      WT;
    typedef Vector<uint32>  BOL;
    typedef Vector<cref_t>  WOL;

    struct SCORS_CMP {
        const Vector<WOL>& wot;
        SCORS_CMP(const Vector<WOL>& wot) : wot(wot) { }
        inline bool operator () (const uint32& a, const uint32& b) const;
    };

    struct CSIZE {
        cref_t ref;
        uint32 size;
        inline CSIZE() : ref(0), size(0) {}
        inline CSIZE(const cref_t& ref, const uint32& size) : ref(ref), size(size) { }
    };

    struct DFS {
        uint32 idx, min;
        inline DFS() : idx(0), min(0) { }
    };

    typedef uint32 cbucket_t;
    typedef SMM<cbucket_t, cref_t> SMM_solver_t;

    class CMM : public SMM_solver_t
    {
        Vector<bool, cref_t> _stencil;

        #define CLAUSEPTR(REF) (Clause*)SMM_solver_t::address(REF)

    public:
        CMM() { 
            assert(SMM_solver_t::bucket() == 4);
            assert(SOLVER_LITSIZE == sizeof(cbucket_t));
            assert(SOLVER_CLAUSESIZE == sizeof(Clause)); 
            assert(SOLVER_CLAUSEBUCKETS == (SOLVER_CLAUSESIZE / SOLVER_LITSIZE) - 2); 
        }
        explicit				CMM             (const cref_t& init_cap) : SMM_solver_t(init_cap), _stencil(init_cap, 0) { assert(SMM_solver_t::bucket() == 4); }
        inline void				init            (const cref_t& nCls, const cref_t& nLits) { 
            SMM_solver_t::init(INITNBUCKETS(nCls, nLits));
            _stencil.resize(nCls * 2, 0);
        }
        
        inline		 Clause&    operator[]		(const cref_t& r)       { return (Clause&)SMM_solver_t::operator[](r); }
        inline const Clause&    operator[]		(const cref_t& r) const { return (Clause&)SMM_solver_t::operator[](r); }
        inline		 Clause*    clause          (const cref_t& r)       { return CLAUSEPTR(r); }
        inline const Clause*    clause          (const cref_t& r) const { return CLAUSEPTR(r); }
        inline       bool*      stencil         ()                     { assert(_stencil.size()); return _stencil.data(); }
        inline       bool		deleted         (const cref_t& r) const { assert(check(r)); return _stencil[r]; }
        inline       void		collectLiterals (const int& size) { junk += size; }
        inline       void		collectClause   (const cref_t& r, const int& size) { 
            junk += CBUCKETS(size);
            assert(check(r));
            _stencil[r] = true; 
        }
        
        inline       void		migrateTo       (CMM& dest) {
            SMM_solver_t::migrateTo(dest);
            _stencil.migrateTo(dest._stencil);
        }
        template <class SRC>
        inline       Clause*	alloc           (cref_t& r, const SRC& src) {
            assert(src.size() > 1);
            r = SMM_solver_t::alloc(CBUCKETS(src.size()));
            Clause* c = new (CLAUSEPTR(r)) Clause(src);
            assert(c->capacity() == CBUCKETS(src.size()));
            assert(src.size() == clause(r)->size());
            _stencil.expand(r + 1, 0);
            return c;
        }
        inline       Clause*	alloc           (cref_t& r, const int& size) {
            assert(size > 1);
            r = SMM_solver_t::alloc(CBUCKETS(size));
            Clause* c = new (CLAUSEPTR(r)) Clause(size);
            assert(c->capacity() == CBUCKETS(size));
            assert(size == c->size());
            _stencil.expand(r + 1, 0);
            return c;
        }
        inline       void		destroy         () { dealloc(), _stencil.clear(true); }
    };

    typedef Vector<cref_t>          BCNF;
    typedef Vector<CSIZE, cref_t>   ClsSchedule;
    typedef Heap<SCORS_CMP>         VarSchedule;

    #define forall_bol(BLIST, PTR) \
		for (uint32* PTR = BLIST, *END = BLIST.end(); PTR != END; ++PTR)

    #define forall_wol(WLIST, PTR) \
		for (cref_t* PTR = WLIST, *END = WLIST.end(); PTR != END; ++PTR)

    #define PREFETCH_CS(CS) \
        const cbucket_t* CS = cm.address(0); \

    #define PREFETCH_CM(CS,DELETED) \
        const cbucket_t* CS = cm.address(0); \
        const bool* DELETED = cm.stencil(); \

}

#endif