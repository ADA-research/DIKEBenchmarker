/***********************************************************************[autarky.cpp]
Copyright(c) 2022, Muhammad Osama - Anton Wijs,
Technische Universiteit Eindhoven (TU/e).

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
**********************************************************************************/

#include "solve.hpp"

using namespace SeqFROST;

// Autartic variables here are eliminated but 
// treated as frozen variables and get values
// like assigned variables (some exceptions
// had to be made in variable mapping though
// to make this acceptable

uint32 Solver::useAutarky(state_t* autarkies)
{
	uint32 eliminated = 0;
	forall_variables(v) {
		const uint32 lit = V2L(v);
		const state_t val = autarkies[lit];
		if (UNASSIGNED(val)) continue;
		LOG2(4, "  eliminating autarkic literal %d", l2i(lit));
		markEliminated(ABS(lit));
		sp->value[lit] = val;
		sp->value[FLIP(lit)] = !val;
		eliminated++;
	}
	return eliminated;
}

uint32 Solver::autarkReasoning(state_t* autarkies)
{
	assert(analyzed.empty());
	const state_t* values = sp->value;
	const VarState* states = sp->state;
	// assign all variables with saved phases
	uint32 assigned = 0;
	forall_variables(v) {
		if (states[v].state) continue;
		assert(sp->phase[v].saved >= 0);
		const uint32 dec = V2DEC(v, sp->phase[v].saved);
		autarkies[dec] = 1;
		autarkies[FLIP(dec)] = 0;
		assigned++;
	}
	// test autarky on large clauses and deduct unassigned
	forall_cnf(orgs, i) {
		const cref_t ref = *i;
		if (cm.deleted(ref)) continue;
		Clause& c = cm[ref];
		if (c.binary()) continue;
		uint32 unassigned = propAutarkClause(false, ref, c, values, autarkies);
		if (unassigned) {
			assert(assigned >= unassigned);
			assigned -= unassigned;
			if (!assigned) return 0;
		}
	}
	LOG2(2, " Autarky %lld: initial large-clause autarky size is %d", stats.autarky.calls, assigned);
	// propagate autarkies on binaries and leave out learnts
	forall_literals(lit) {
		if (inactive(lit)) continue;
		state_t val = autarkies[lit];
		if (val > 0) continue;
		WL& ws = wt[FLIP(lit)];
		forall_watches(ws, i) {
			const Watch w = *i;
			assert(w.binary());
			const cref_t ref = w.ref;
			assert(!cm.deleted(ref));
			if (cm[ref].learnt()) continue;
			const uint32 other = w.imp;
			assert(UNASSIGNED(values[other]));
			const state_t otherval = autarkies[other];
			if (otherval > 0) continue;
			if (!val) {
				cancelAutark(true, lit, autarkies);
				val = UNDEF_VAL;
				assert(assigned > 0);
				if (!--assigned)
					break;
			}
			if (!otherval) {
				cancelAutark(true, other, autarkies);
				assert(assigned > 0);
				if (!--assigned)
					break;
			}
		}
		if (analyzed.size()) {
			const uint32 unassigned = propAutarky(values, autarkies);
			assert(unassigned <= assigned);
			assigned -= unassigned;
		}
		if (!assigned) return 0;
	}
	LOG2(2, " Autarky %lld: initial binary-clause autarky size is %d", stats.autarky.calls, assigned);
	// propagate autarkies on large clauses
	forall_cnf(orgs, i) {
		const cref_t ref = *i;
		if (cm.deleted(ref)) continue;
		Clause& c = cm[ref];
		if (c.binary()) continue;
		uint32 unassigned = propAutarkClause(true, ref, c, values, autarkies);
		if (unassigned) {
			unassigned += propAutarky(values, autarkies);
			assert(assigned >= unassigned);
			assigned -= unassigned;
			if (!assigned) break;
		}
		else if (!cm.deleted(ref)) {
			forall_clause(c, k) {
				const uint32 lit = *k;
				if (UNASSIGNED(values[lit]) && autarkies[lit] > 0) {
					wt[FLIP(lit)].push(Watch(ref, c.size(), lit));
				}
			}
		}
	}
	LOG2(2, " Autarky %lld: final autarky size is %d", stats.autarky.calls, assigned);
	// eliminate autarkies
	if (assigned) {
		const uint32 eliminated = useAutarky(autarkies);
		assert(eliminated == assigned);
		stats.autarky.eliminated += eliminated;
		cnfstats.maxMelted += eliminated;
		LOG2(2, " Autarky %lld: eliminated %d autarkic variables", stats.autarky.calls, eliminated);
		filterAutarky();
	}
	else
		detachClauses(true);
	return assigned;
}

void Solver::autarky()
{
	if (!opts.autarky_en || incremental) return;
	if (!UNSOLVED) return;
	SLEEPING(sleep.autarky, opts.autarky_sleep_en);
	assert(!LEVEL);
	stats.autarky.calls++;
	// at this step only all binaries are left
	// but learnts are ignored in reasoning 
	// which save time to reattach them again
	binarizeWT(true);
	state_t* autarkies = sfmalloc<state_t>(cnfstats.maxLit);
	memset(autarkies, UNDEF_VAL, cnfstats.maxLit);
	uint32 eliminated = autarkReasoning(autarkies);
	analyzed.clear();
	std::free(autarkies);
	PREFETCH_CM(cs, deleted);
	attachNonBins(orgs, cs, deleted, true);
	attachNonBins(learnts, cs, deleted, true);
	if (retrail()) LOG2(2, " Propagation after autarky proved a contradiction");
	UPDATE_SLEEPER(autarky, eliminated);
	printStats(eliminated, 'k', CCYAN);
}

void Solver::filterAutarky()
{
	const VarState* states = sp->state;
	forall_literals(lit) {
		const bool litelim = MELTED(states[ABS(lit)].state);
		WL& ws = wt[FLIP(lit)];
		Watch* j = ws;
		forall_watches(ws, i) {
			const Watch w = *i;
			if (w.binary()) {
				const uint32 imp = w.imp;
				CHECKLIT(imp);
				const bool impelim = MELTED(states[ABS(imp)].state);
				if (litelim || impelim) {
					if (lit < imp) {
						const cref_t ref = w.ref;
						removeClause(cm[ref], ref);
					}
				}
				else
					*j++ = w;
			}
		}
		ws.resize(uint32(j - ws));
	}
}

uint32 Solver::propAutarky(const state_t* values, state_t* autarkies)
{
	assert(!LEVEL);
	uint32 unassigned = 0;
	while (analyzed.size()) {
		const uint32 lit = analyzed.back();
		analyzed.pop();
		CHECKLIT(lit);
		assert(UNASSIGNED(autarkies[lit]));
		LOG2(4, "  propagating autarkic literal %d", l2i(lit));
		WL& ws = wt[FLIP(lit)];
		Watch* j = ws;
		forall_watches(ws, i) {
			const Watch w = *i;
			const cref_t ref = w.ref;
			Clause& c = cm[ref];
			if (w.binary()) {
				*j++ = w;
				if (c.learnt()) continue;
				const uint32 imp = w.imp;
				CHECKLIT(imp);
				assert(imp != lit);
				state_t impval = values[imp];
				if (impval > 0) continue;
				assert(UNASSIGNED(impval));
				if (!autarkies[imp]) {
					cancelAutark(true, imp, autarkies);
					unassigned++;
				}
			}
			else {
				assert(ABS(w.imp) == ABS(lit));
				unassigned += propAutarkClause(true, ref, c, values, autarkies);
			}
		}
		ws.resize(uint32(j - ws));
	}
	return unassigned;
}

inline void Solver::cancelAutark(const bool& add, const uint32& lit, state_t* autarkies)
{
	const uint32 fit = FLIP(lit);
	assert(autarkies[fit] > 0);
	autarkies[lit] = autarkies[fit] = UNDEF_VAL;
	if (add) analyzed.push(fit);
}

inline uint32 Solver::propAutarkClause(const bool& add, const cref_t& ref, Clause& c, const state_t* values, state_t* autarkies)
{
	assert(c.size() > 2);
	assert(c.original());
	assert(!cm.deleted(ref));
	LOGCLAUSE(4, c, "   autarky propagating clause");
	bool satisfied = false, falsified = false;
	forall_clause(c, k) {
		const uint32 other = *k;
		state_t otherval = values[other];
		if (otherval > 0) {
			removeClause(c, ref);
			return 0;
		}
		if (otherval) { // unassigned
			otherval = autarkies[other];
			if (otherval > 0) satisfied = true;
			else if (!otherval) falsified = true;
		}
	}
	if (satisfied || !falsified) return 0;
	uint32 unassigned = 0;
	forall_clause(c, k) {
		const uint32 other = *k;
		const state_t otherval = values[other];
		if (otherval) {
			assert(UNASSIGNED(otherval));
			if (!autarkies[other]) {
				cancelAutark(add, other, autarkies);
				assert(unassigned <= cnfstats.maxVar);
				unassigned++;
			}
		}
	}
	return unassigned;
}

