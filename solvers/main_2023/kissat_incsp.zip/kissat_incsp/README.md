
The Kissat-INCSP SAT Solver
=====================

`kissat-inc`, one of the best solvers in SAT 2022 is based on `kissat` solver from SAT 2020.

Kissat is a "keep it simple and clean bare metal SAT solver" written in C. It is a port of CaDiCaL back to C with improved data structures, better scheduling of inprocessing and optimised algorithms and implementation.



`kissat-incsp` is an improved version of `kissat-inc` in which optimisations based on insights obtained from micro-architectural profiling have been incorporated.

Specifically it includes:

- a cache friendly queue for a set of variables corresponding to each literal (changes made to file: `src/queue.c`)
- using software prefetching to make the watchlist entries available in the cache by the time program accesses them (changes made to file: `src/propsearch.c`)

No algorithmic changes are made to the `kissat-inc` solver. All performance improvements are attributable to the micro-architectural optimisations referred above.



Run `./configure && make test` to configure, build and test in `build`.



## Authors

- Karthikeya Namoju (karthikeyaiitb@gmail.com), CSE dept., IIT Bombay
- Kalind Karia (kalind1610@gmail.com), EE dept., IIT Bombay
- Supratik Chakraborty (supratik@cse.iitb.ac.in), CSE dept., IIT Bombay
- Biswabandan Panda (biswa@cse.iitb.ac.in), CSE dept., IIT Bombay



## Original Credits

- kissat, 2020: Armin Biere, Katalin Fazekas, Mathias Fleury, Maximilian Heisinger, Johannes Kepler University Linz, Austria
- kissat-inc, 2022: Shaowei Cai, Xindi Zhang, Zhihan Chen, Pinyan Lu, ISCAS, China
