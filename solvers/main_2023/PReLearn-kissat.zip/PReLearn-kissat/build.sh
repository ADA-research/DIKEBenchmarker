#!/bin/sh

(cd sadical; ./configure.sh && make)
(cd kissat; ./configure && make)

