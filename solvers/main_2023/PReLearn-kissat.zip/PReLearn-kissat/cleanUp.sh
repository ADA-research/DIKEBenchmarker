#!/bin/sh

(cd kissat; make clean)
(cd sadical; make clean)
