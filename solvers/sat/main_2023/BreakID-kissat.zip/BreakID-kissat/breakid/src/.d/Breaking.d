obj/Breaking.o: Breaking.cpp Breaking.hpp global.hpp Algebraic.hpp \
 Theory.hpp
Breaking.hpp:
global.hpp:
Algebraic.hpp:
Theory.hpp:
