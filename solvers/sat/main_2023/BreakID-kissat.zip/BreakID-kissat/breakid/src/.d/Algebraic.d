obj/Algebraic.o: Algebraic.cpp global.hpp Algebraic.hpp Theory.hpp \
 Breaking.hpp Graph.hpp
global.hpp:
Algebraic.hpp:
Theory.hpp:
Breaking.hpp:
Graph.hpp:
