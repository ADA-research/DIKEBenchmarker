obj/Graph.o: Graph.cpp Graph.hpp global.hpp Algebraic.hpp saucy.h
Graph.hpp:
global.hpp:
Algebraic.hpp:
saucy.h:
