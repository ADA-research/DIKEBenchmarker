obj/Theory.o: Theory.cpp Theory.hpp global.hpp Graph.hpp Algebraic.hpp \
 Breaking.hpp
Theory.hpp:
global.hpp:
Graph.hpp:
Algebraic.hpp:
Breaking.hpp:
