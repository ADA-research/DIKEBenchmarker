obj/BreakID.o: BreakID.cpp Graph.hpp global.hpp Algebraic.hpp Theory.hpp \
 Breaking.hpp
Graph.hpp:
global.hpp:
Algebraic.hpp:
Theory.hpp:
Breaking.hpp:
