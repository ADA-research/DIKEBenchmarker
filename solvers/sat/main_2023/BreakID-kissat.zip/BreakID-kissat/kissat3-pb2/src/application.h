#ifndef _application_h_INCLUDED
#define _application_h_INCLUDED

#include "parse.h"
#include "internal.h"
#include <inttypes.h>
#include <string.h>
#include <unistd.h>
#include "error.h"

typedef struct application application;

struct application
{
  kissat *solver;
  const char *input_path;
#ifndef NPROOFS
  const char *proof_path;
  file proof_file;
  int binary;
#endif
#if !defined(NPROOFS) || !defined (_POSIX_C_SOURCE)
  bool force;
#endif
  int time;
  int conflicts;
  int decisions;
  strictness strict;
  bool partial;
  bool witness;
  int max_var;
};
//struct kissat;
#define ERROR(...) \
do { \
  kissat_error (__VA_ARGS__); \
  return false; \
} while (0)

int kissat_application (struct kissat *, int argc, char **argv);

#endif
